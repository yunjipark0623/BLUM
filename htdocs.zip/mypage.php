<!DOCTYPE html>
<html>

<head>
    <!-- index.html -->
    <meta charset="utf-8">
    <!-- 반응형 웹을 위한 Bootstrap 설정 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap MaxCDN 정의-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


</head>

<body>
    <nav class="navbar" style="background-color: blanchedalmond;">
        <div class="container">
            <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#MyNav">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index_my.html">BLUM</a>
            </div>
            <div class="collapse navbar-collapse" id="MyNav">



                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <form class="navbar-form navbar-header" action="#">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="glyphicon glyphicon-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                    <li><a href="../people.html"><span class="glyphicon glyphicon-user"></span> Blums</a></li>
                    <li><a href="./mypage.php"><span class="glyphicon glyphicon-user"></span> 마이페이지</a></li>
                    <li><a href="./logout.php"><span class="glyphicon glyphicon-log-in"></span> 로그아웃</a></li>

                </ul>
            </div>
    </nav>


    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <div class="container">
        <div class="row">
            <br>
            <br>
            <br>
            <div class="col-lg-3 col-md-4">
                <div class="text-center card-box">
                    <div class="member-card">
                        <div class="thumb-xl member-thumb m-b-10 center-block">
                            <img src="https://media.vingle.net/images/ca_l/4jbehl9l0v.jpg" class="img-circle img-thumbnail" alt="profile-image">
                        </div>

                        <div class="">
                            <!-- <h4 class="m-b-5"> -->
                                    <?php 
                                        session_start();
                                        $name = $_SESSION["userid"];
                                        print "<h4>$name</h4>";
                                    ?>
                            <!-- </h4> -->

                        </div>
                    </div>
                </div> <!-- end card-box -->


            </div> <!-- end col -->


            <div class="col-md-8 col-lg-9">
                <div class="">
                    <div class="">
                        <ul class="nav nav-tabs navtab-custom">
                            <li class="active">
                                <a href="#profile" data-toggle="tab" aria-expanded="true">
                                    <span class="visible-xs"><i class="fa fa-photo"></i></span>
                                    <span class="hidden-xs">GALLERY</span>
                                </a>
                            </li>
                        </ul>

                        <div class="tab-pane active" id="profile">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="http://www.naver.com" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/05/04/16/05/mckenzie-river-5129717__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Mckenzie River</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/05/04/16/02/horseshoe-bend-5129704__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Horseshoe Bend</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/05/04/16/07/tumalo-falls-5129725__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Tumalo Falls</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/05/04/16/01/redwoods-5129698__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Redwoods National</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>



                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/05/04/16/10/winter-5129737__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Winter Forest</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/05/04/17/29/benham-falls-5129940__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Benham Falls</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/04/17/21/16/santorini-5056952__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Santorini Greece</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/04/12/07/55/cat-5033194__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Cat Pussy Feline</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="gal-detail thumb">
                                        <a href="#" class="image-popup" title="Screenshot-2">
                                            <img src="https://cdn.pixabay.com/photo/2020/01/26/06/36/dog-4793950__340.jpg" class="thumb-img" alt="work-thumbnail" width="290" height="300">
                                        </a>
                                        <h4 class="text-center">Dog Spaniel Cut Fur</h4>
                                        <div class="ga-border"></div>

                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->
    </div>
</body>

</html>